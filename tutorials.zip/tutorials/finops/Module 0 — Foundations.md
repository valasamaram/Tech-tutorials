# 📘 **Module — Cloud Basics, Billing Fundamentals & FinOps Principles**

### 🎯 **Goal: Understand cloud basics, billing fundamentals, and FinOps principles (Beginner → Intermediate)**

---

# 🌥️ **1. Cloud Computing Basics**

Cloud computing is the on-demand delivery of computing services—servers, storage, databases, networking, analytics, and software—over the internet with pay-as-you-go pricing.

### 🔑 Key Characteristics

* **On-demand self-service** – Provision resources instantly.
* **Scalability & elasticity** – Scale up/down automatically based on load.
* **Measured service** – Pay only for what you use.
* **Resource pooling** – Shared infrastructure; multi-tenant.
* **Broad network access** – Accessible via internet or private networks.

---

## 🟦 1.1 Cloud Service Models

### Overview
Cloud service models define how responsibility is shared between you and the cloud provider. The three core models — IaaS, PaaS and SaaS — trade control for operational simplicity. Use the guidance below to match workload needs to the right model.

### IaaS — Infrastructure as a Service

What: Virtual compute, storage, and networking that you provision and manage. The cloud provider owns and operates the datacenter and hypervisor; you manage the OS, middleware, runtime, applications and data.

Azure examples: Azure Virtual Machines (VM), Managed Disks, Virtual Network (VNet), VM Scale Sets (VMSS).

Why use IaaS:
- Lift-and-shift legacy applications with minimal refactor.
- Run custom OS/kernel modules or unsupported runtimes.
- Maintain maximum control over OS-level configuration and security.

How it works (short):
- Provision VMs or VMSS, attach managed disks, connect to VNets and NSGs, and run configuration/patching tooling (e.g., Update Management, Ansible).

Benefits:
- Full administrative control and broad compatibility with existing software.

Pros:
- Maximum flexibility and control.
- Fast rehosting for migrations.

Cons:
- Higher operational overhead (patching, backups, hardening).
- More work to automate scaling and resilience compared to PaaS.

When to choose IaaS: legacy enterprise apps, applications requiring kernel/custom drivers, or temporary rehosting as a first migration step.

Common migration pattern: Rehost (lift-and-shift) → Replatform (move components to managed services) → Refactor (decompose into PaaS/microservices).

Pitfalls & mitigations:
- Oversized VMs: enforce monitoring and rightsizing cadence.
- Unmanaged patching: implement automated patching pipelines and baselines.

---

### PaaS — Platform as a Service

What: Managed runtime and platform services where the provider handles OS, runtime, scaling, and much of the operational plumbing. You focus on application code and configuration.

Azure examples: Azure App Service, Azure SQL Database (single/db pool/managed instance), Azure Functions, Azure Web Apps, Azure Container Instances.

Why use PaaS:
- Speed up development and delivery (CI/CD friendly).
- Offload patching, OS management and many operational tasks.
- Benefit from built-in scaling, monitoring, and integrations.

How it works (short):
- Deploy code or container images; the platform provisions runtime instances, scales automatically, and integrates with managed services (databases, identity, storage).

Benefits:
- Faster time-to-market and lower operational burden.
- Managed HA, backups and patching for platform services.

Pros:
- Focus on business logic, not infrastructure.
- Often better long-term TCO for common workloads.

Cons:
- Less control over the underlying runtime and OS.
- Potential vendor lock-in to platform-specific features or APIs.

When to choose PaaS: web/front-end APIs, modern microservices, managed databases, and when developer velocity and operational simplicity are priorities.

Migration pattern: Replatform — move app components to managed stacks and adapt deployment pipelines.

Pitfalls & mitigations:
- Hidden costs (autoscale, egress): model and monitor costs in staging environments.
- Unsupported customizations: validate platform capabilities early and use containers/AKS when deeper control is required.

---

### SaaS — Software as a Service

What: Fully managed applications delivered over the internet where the vendor operates the entire stack. You manage users, configuration and data within the app.

Examples: Microsoft 365, Dynamics 365, Salesforce, Slack.

Why use SaaS:
- Minimal operational overhead for commodity functions (email, CRM, collaboration).
- Fast onboarding and automatic feature updates.

How it works (short):
- Subscribe to the service, configure tenancy and access, and consume functionality via web or API. The provider handles updates, scaling and availability.

Benefits:
- Lowest operational burden and fastest time-to-value.
- Often includes integration points (SSO, APIs) and built-in compliance tools.

Pros:
- Quick adoption, predictable operations, built-in support and upgrades.

Cons:
- Limited customization and extensibility.
- Data residency and vendor lock-in risks; licensing management overhead.

When to choose SaaS: non-differentiating business capabilities (email, HR, CRM) where vendor functionality meets business needs.

Pitfalls & mitigations:
- Sensitive data controls: review contracts, use customer-managed keys and apply conditional access where supported.
- Cost creep from feature/seat proliferation: enforce license governance.

---

## Decision guidance — quick checklist

For each workload, answer these questions to pick a service model:
- Does the workload need OS/kernel-level control or custom drivers? → IaaS
- Can the application run on a managed runtime or be containerized? → PaaS/Containers
- Is the capability commoditized (email, payroll)? → SaaS
- Are compliance/data residency constraints strict? → Private cloud or Hybrid choices may apply
- What is the team's operational maturity (SRE/ops skills)? Low → favor PaaS/SaaS; High → IaaS viable

## Migration patterns (short)
- Rehost (lift-and-shift): fastest move to IaaS.
- Replatform: move to PaaS-managed components to reduce ops.
- Refactor/Rewrite: decompose into cloud-native services (PaaS/serverless).
- Replace: adopt SaaS that replaces in-house functionality.

## Interview-style questions (practice)
- Explain when you'd choose PaaS over IaaS — give 3 real examples.
- How would you migrate a 10-year-old monolith to Azure with minimal downtime?
- Compare Azure SQL (PaaS) vs SQL Server on VM (IaaS): trade-offs and operational impacts.

## Quick checklist to include in the module
- Add 1–2 Azure example architectures per model (web app, ETL pipeline, ERP)
- Add the 6-question decision checklist to every workload assessment
- Provide one short migration playbook example (lift-and-shift → replatform)

---

## 🟦 1.2 Cloud Deployment Models

### **Public Cloud**

Third-party provider delivers services (Azure, AWS, GCP).

### **Private Cloud**

Cloud environment dedicated to one organization.

### **Hybrid Cloud**

Mix of on-prem + cloud, integrated via networking.

### **Multi-Cloud**

Using more than one cloud provider for redundancy or cost optimization.

---

# 🧱 **2. Azure Billing Fundamentals**

To optimize cloud cost, understanding Azure billing is mandatory. Azure uses a **consumption-based billing model** with multiple components:

---

## 🟦 2.1 Azure Account Structure

### **Tenant**

* Identity boundary (Microsoft Entra ID).
* Manages users, groups, roles.

### **Subscription**

* Billing boundary.
* All resources *must* belong to a subscription.

### **Resource Groups**

* Logical grouping of related resources.

### **Management Groups**

* Govern multiple subscriptions.

---

## 🟦 2.2 Azure Cost Model

Azure charges based on:

### **✔ Compute**

* Price based on **vCPU, memory, region, OS, reservation term**

### **✔ Storage**

* Capacity used (GB), redundancy type, performance tier

### **✔ Networking**

* Outbound data transfer
* Public IP, VPN, ExpressRoute

### **✔ Databases**

* DTU/vCore, storage, backup retention, geographic redundancy

### **✔ Platform Services**

* Function execution units
* Logic App actions
* API management requests

### 🔹 Charges are **per-minute or per-second**, depending on service.



# 🟦 **2.2 Azure Cost Model — With Approximate Costs**

## ✔ **Compute Costs (VMs, AKS Node Pools, App Service Plans)**

Compute is usually your **largest Azure bill**. Below are typical estimates.

### **💠 Virtual Machines (Linux pricing)**

Approx monthly cost (India Central region as reference):

| VM Size                                | vCPU / RAM  | Approx Monthly Cost |
| -------------------------------------- | ----------- | ------------------- |
| **B1s**                                | 1 / 1 GB    | ₹450–₹600           |
| **D2s_v3**                             | 2 / 8 GB    | ₹4,500–₹5,500       |
| **D4s_v3**                             | 4 / 16 GB   | ₹9,000–₹11,000      |
| **D8s_v3**                             | 8 / 32 GB   | ₹18,000–₹22,000     |
| **F-series** (compute optimized)       | 4 / 8 GB    | ₹8,500–₹10,000      |
| **E-series** (memory optimized)        | 8 / 64 GB   | ₹25,000–₹32,000     |
| **M-series** (Heavy memory DB servers) | 32 / 512 GB | ₹3–5 lakh per month |

### **💠 Windows VMs Cost More**

Add **40–80% extra** due to licensing.

### **💠 AKS Node Pools**

AKS itself is **free**.
You pay only for **worker nodes = VM cost**.

Example:

* 3 × D4s_v3 nodes → ~₹30,000/month

### **💠 App Service Plans**

Approx monthly cost:

| Plan     | Price Range     |
| -------- | --------------- |
| **B1**   | ₹750 / month    |
| **S1**   | ₹5,000–₹6,000   |
| **P1v3** | ₹20,000–₹25,000 |
| **P2v3** | ₹40,000–₹50,000 |


---

# 🧠 **What Does Compute / Memory / Storage Optimization Mean?**

Cloud providers like Azure classify VM families based on **what type of workload they are built for**.
Each VM type is optimized for a specific resource:

* **Compute (CPU)**
* **Memory (RAM)**
* **Storage/IOPS**
* **GPU**
* **High-memory database workloads**

Understanding these helps you choose the **right VM for the right workload**, avoid overprovisioning, and reduce cost.

---

# 🟦 **1. Compute Optimized VMs (High CPU)**

### 📌 What it means

These VMs have **more CPU (vCPUs) relative to RAM**.
They provide **high CPU performance**, suitable for workloads that need strong processing power but not too much memory.

### 📌 Azure Examples

* **F-series** → Compute optimized
  Eg: F4s_v2 (4 vCPU, 8 GB RAM)

### 📌 Why they exist

Some apps need **lots of CPU instructions** but only moderate memory.
Examples:

* Batch processing
* Gaming servers
* Web servers
* Application servers
* CI/CD pipelines
* Encoding workloads

### 📌 When to use compute-optimized?

If your application:

* Uses high CPU
* Runs heavy computations
* Has many background threads
* Is not memory-heavy

---

# 🟨 **2. Memory Optimized VMs (High RAM)**

### 📌 What it means

These VMs have **more RAM per vCPU**, meaning applications that need large working memory perform better.

### 📌 Azure Examples

* **E-series** → Memory optimized
  Eg: E8s_v4 (8 vCPUs, 64 GB RAM)
* **D-series (some types)** → Balanced but also good for memory workloads

### 📌 Why they exist

Many applications require **large amounts of RAM** for:

* Caching
* Large in-memory datasets
* Analytics
* High-performance databases

### 📌 When to use memory-optimized?

Use for:

* SQL Server
* Azure SQL Managed Instance
* Redis caching
* Elasticsearch
* SAP applications
* Analytical workloads

---

# 🟥 **3. Heavy Memory DB Servers (Extra High RAM Servers)**

### 📌 What it means

These VMs are specifically designed for **very large databases** that require **hundreds of GB to multiple TB of RAM**.

They provide:

* Extremely high memory
* High throughput
* High IOPS storage
* Support for enterprise-grade databases

### 📌 Azure Examples

* **M-series VMs**
* **Msv2-series**
* **Mv3-series (latest)**

### Typical sizes:

| VM Type   | RAM    |
| --------- | ------ |
| M16ms     | 512 GB |
| M32ts     | 1 TB   |
| M64ms     | 1.7 TB |
| M128ms    | 4 TB   |
| M208ms v2 | 5.7 TB |

### 📌 Why they exist?

For **enterprise-level databases**, such as:

* SQL Server Enterprise
* SAP HANA
* Oracle DB
* Very large OLAP systems
* In-memory databases

These databases must:

* Cache large tables
* Process billions of transactions
* Handle huge analytical workloads

### 📌 When to use heavy-memory VMs?

If your workload:

* Uses SAP HANA
* Requires more than 500GB RAM
* Has large DB buffer pool needs
* Needs high IOPS + high memory

---

# 🟩 Summary Table: Differences

| Type                        | What it means       | Typical Workloads              | Azure VM Families |
| --------------------------- | ------------------- | ------------------------------ | ----------------- |
| **Compute Optimized**       | More CPU, less RAM  | API servers, batch jobs, CI/CD | F-series          |
| **Memory Optimized**        | More RAM per CPU    | SQL, Redis, analytics          | E-series          |
| **Heavy Memory DB Servers** | Extremely large RAM | SAP HANA, enterprise DBs       | M-series          |

---

# 🧠 Why This Matters (FinOps & Engineering Perspective)

### ✔ Right VM type → maximum performance

### ✔ Wrong VM type → huge waste

Example:

If you run SQL Server on **F-series (compute optimized)**:
❌ CPU is plenty
❌ RAM is insufficient
❌ SQL Server performs poorly
❌ High cost due to CPU bottlenecks

If you run a small web server on **M-series**:
❌ You pay lakhs per month unnecessarily

Picking the right VM family → **30–70% cost reduction**.

---

# ✔ **Storage Costs**

### **💠 Blob Storage**

Per GB per month:

| Tier        | Cost per GB    |
| ----------- | -------------- |
| **Hot**     | ₹1.5–₹2 per GB |
| **Cool**    | ₹0.8–₹1 per GB |
| **Archive** | ₹0.2 per GB    |

Example:
**1 TB Hot storage ≈ ₹1,500–₹2,000/month**

---

### **💠 Managed Disks**

Monthly cost (approx):

| Disk Type        | Size   | Cost                         |
| ---------------- | ------ | ---------------------------- |
| **Standard HDD** | 128GB  | ~₹300                        |
| **Standard SSD** | 128GB  | ~₹500                        |
| **Premium SSD**  | 128GB  | ~₹1,200                      |
| **Premium SSD**  | 512GB  | ~₹5,000                      |
| **Ultra Disk**   | Custom | very high (varies with IOPS) |


---

# 🔵 Azure Disk Types Explained (HDD vs SSD vs Ultra Disk)

Azure offers multiple disk types to balance **cost**, **performance**, and **workload requirements**. The main categories are:

---

# 🟡 **1. HDD (Hard Disk Drive)**

### ✔ What it is:

Traditional spinning disk—mechanical storage.

### ✔ Characteristics:

* Lowest cost
* Lowest performance
* Higher latency
* Good for cold/stale data

### ✔ Common Use Cases:

* Backup
* Archive
* Rarely accessed data
* Dev/test environments

### ✔ Performance:

* Throughput: **up to ~500 MB/s**
* IOPS: **<500 IOPS**

### ✔ Approx Cost:

* **Very cheap**
* Example: ~₹2–₹4 per GB/month (region-dependent)

---

# 🟢 **2. SSD (Solid State Drive)**

Azure has 3 SSD types:

* **Standard SSD**
* **Premium SSD**
* **Premium SSD v2**

### ✔ What it is:

Flash-based storage with fast read/write performance.

### ✔ Characteristics:

* Faster & more reliable than HDD
* Supports latency-sensitive workloads
* Premium tiers support high IOPS and throughput

### ✔ Common Use Cases:

* Production VMs
* Application servers
* DB servers (small to medium)
* Web apps

### ✔ Performance:

* **Standard SSD**: 500–6000 IOPS
* **Premium SSD**: 125–20,000 IOPS
* **Premium SSD v2**: up to **80,000+ IOPS**

### ✔ Approx Cost:

* Standard SSD: ~₹6–₹10 per GB/month
* Premium SSD: Tier-based → P10, P20, P30, etc.
  Example: P30 (~1 TB) ≈ ₹10,000–₹14,000 per month

---

# 🔴 **3. Ultra Disk**

Ultra-high-performance disk designed for **mission-critical workloads**.

### ✔ What it is:

Next-gen SSD with *extreme I/O capabilities*.
Allows dynamically changing IOPS & throughput without downtime.

### ✔ Characteristics:

* Lowest latency in Azure (sub-milliseconds)
* Very high IOPS
* Very high throughput
* Used for maximum performance environments

### ✔ Common Use Cases:

* Large & high-traffic databases
* Mission-critical transactional systems
* Financial workloads
* Real-time analytics

### ✔ Performance:

* IOPS: **Up to 160,000+ IOPS per disk**
* Throughput: **4,000 MB/s+**

### ✔ Approx Cost:

* **Most expensive disk in Azure**
* Can cost **₹30,000 to ₹2,00,000+ per month** depending on IOPS configuration

---

# ⚡ Quick Summary Table

| Disk Type            | Speed     | Cost      | Best For                            |
| -------------------- | --------- | --------- | ----------------------------------- |
| **HDD**              | Slow      | Low       | Backup, archive, cold storage       |
| **Standard SSD**     | Medium    | Moderate  | Web servers, dev/prod apps          |
| **Premium SSD / v2** | Fast      | High      | DBs, enterprise workloads           |
| **Ultra Disk**       | Very Fast | Very High | High-performance DBs, critical apps |

---

# 🧠 Put Simply:

* **HDD** = Cheapest, slowest
* **SSD** = Balanced performance vs cost
* **Premium SSD** = Fast
* **Ultra Disk** = Super fast, very expensive


---

### **💠 Backup Storage**

* Azure Backup vault: **~₹0.6 to ₹1.5 per GB**
* 1 TB backup ≈ **₹600–₹1,500/month**

---

# ✔ **Networking Costs**

### **💠 Data Transfer (Egress)**

Inbound = FREE
Outbound = Charged

| Amount     | Cost         |
| ---------- | ------------ |
| First 5 GB | Free         |
| Next 10 TB | ₹6–₹9 per GB |

Example:

* 1 TB (1000 GB) outbound → ₹6,000–₹9,000/month

---

### **💠 VPN / ExpressRoute**

* **VPN Gateway**: ₹9,000–₹30,000/month
* **ExpressRoute Circuit**: ₹40,000–₹2,00,000/month (depending on bandwidth)

### **💠 Public IP**

* Basic: Free
* Standard: ₹300–₹600/month

---

# ✔ **Database Costs**

### **💠 Azure SQL Database**

Per month approx:

| Tier                               | Cost            |
| ---------------------------------- | --------------- |
| **Basic (DTU)**                    | ₹350–₹450       |
| **S2**                             | ₹6,000–₹8,000   |
| **P1**                             | ₹40,000–₹50,000 |
| **vCore General Purpose 2vCore**   | ₹15,000–₹18,000 |
| **vCore Business Critical 2vCore** | ₹40,000–₹55,000 |

### **💠 SQL Managed Instance**

* General Purpose: ₹40,000–₹80,000
* Business Critical: ₹1–2 lakhs per instance

### **Storage additional**

* Premium Storage: ₹10–₹15 per GB
* Backup Storage: ₹0.5–₹1 per GB

---

# ✔ **Platform Services (Serverless/PaaS)**

### **💠 Azure Functions**

Costs:

* First **1 million requests = FREE**
* After that: **₹15–₹25 per million requests**
* Additional charges for execution time (GB-seconds)

A typical app costs **₹100–₹500/month**.


---

# ⚡ **Azure Functions Billing Breakdown**

Azure Functions (Consumption Plan) charges you based on two things:

---

# ✅ **1. Requests (Executions)**

### ✔ What is a “Request”?

A **request = 1 function execution**.

Any time your function **runs**, it counts as *one request*.

Examples:

* An HTTP-triggered function is called → **1 request**
* A timer-triggered function runs every minute → **1 request per minute**
* A queue-triggered function processes one message → **1 request per message**

### 💰 **Cost**

* First **1 million requests = FREE**
* After that: **₹15–₹25 per 1 million requests**

---

# ✅ **2. Execution Time (GB-seconds)**

This is the **main cost component**.

Azure calculates this using:

```
Memory allocated (GB) × Time the function runs (seconds)
```

### ✔ What does this mean?

1. Azure assigns memory to your function (128 MB, 256 MB, 512 MB, 1 GB...).
2. Every time your function runs, Azure measures how long it runs.
3. Then it multiplies:

```
Memory × Duration = GB-seconds
```

### 📌 Example

Let’s say your function uses **512 MB (0.5 GB)**
And it runs for **0.5 seconds** per execution.

```
0.5 GB × 0.5 seconds = 0.25 GB-seconds
```

If it runs **1 million times**:

```
1,000,000 × 0.25 GB-seconds = 250,000 GB-seconds
```

You get **400,000 GB-seconds FREE** every month.
Only the extra is billed.

### 💰 Cost (Execution)

Pricing: **₹0.123 per 1,000,000 GB-seconds** (approx)

---

# 🧠 **In simple words…**

### 🔹 **Request = how many times your function is triggered**

### 🔹 **GB-seconds = how much memory and time your function consumes**

---

# 🟢 Quick Example — Real Billing Scenario

User sends 50,00,000 API calls to your HTTP Function.

* Requests = 5M
* Free = 1M
* Billable = 4M → 4 × ₹20 = ₹80 approx

Function each time uses:

* Memory = 512 MB (0.5 GB)
* Duration = 1 second

So **GB-seconds per run = 0.5 × 1 = 0.5**

Total GB-seconds = 5M × 0.5 = **2,500,000**
Free = 400,000
Billable = **2,100,000 GB-s** → around ₹260

---

# ⭐ Final Summary

| Component                   | What it means                     | Charged?  |
| --------------------------- | --------------------------------- | --------- |
| **Requests**                | Number of times the function runs | Yes       |
| **Execution Time (GB-sec)** | Memory consumed × runtime         | Yes       |
| **First 1M requests**       | Free                              | No charge |
| **First 400,000 GB-sec**    | Free                              | No charge |

---

### **💠 Logic Apps**

* ~₹0.08–₹0.20 per action
* Heavy workflows: ₹5,000–₹30,000 per month

Here is a **clear and correct explanation** of Logic App pricing — especially **what is an 
---

# 💠 **Logic Apps Pricing Explained (Simple & Practical)**

Logic Apps charge you **per action execution**.

---

# ✅ **1. What is an Action?**

An **action = any step inside the Logic App**.

Examples of **billable actions**:

| Type                          | Example                                | Count as Action?      |
| ----------------------------- | -------------------------------------- | --------------------- |
| **Trigger**                   | HTTP trigger, Recurrence trigger       | ✔ Yes                 |
| **Data operations**           | Parse JSON, Compose, For Each          | ✔ Yes                 |
| **Connectors**                | SQL, Service Bus, Office 365, Azure AD | ✔ Yes (special rates) |
| **Control actions**           | Condition, Switch, Delay               | ✔ Yes                 |
| **Calling another Logic App** | Child workflow                         | ✔ Yes                 |

Each time the workflow runs, each action inside it **costs money**.

---

# 💰 **2. Approx Cost per Action**

### **Standard Actions** (HTTP, control, data ops)

➡ **₹0.08 – ₹0.20 per action**

### **Premium Connectors** (SQL, SP, SAP, Service Bus, Dynamics 365)

➡ **₹0.50 – ₹3 per action**

### **Enterprise Connectors**

➡ **₹3 – ₹12 per action**

---

# 📌 **3. Example Cost Calculation**

Let’s say your Logic App runs 10,000 times per day
and contains **5 actions**:

```
Daily actions = 10,000 × 5 = 50,000 actions
```

Cost (₹0.10 per action):

```
50,000 × 0.10 = ₹5,000 per day
Monthly = ₹5,000 × 30 = ₹150,000 (₹1.5 lakh)
```

Yes — Logic Apps can get **very expensive** if the workflow is heavy.

---

# 🎯 **4. Why Heavy Workflows Cost ₹5,000–₹30,000+?**

### Example Heavy Workflow

* 20 actions per run
* 5,000 runs per day

Total actions per day:

```
20 × 5,000 = 100,000 actions
```

Cost:

```
100,000 × ₹0.10 = ₹10,000 per day
Monthly = ₹3,00,000
```

Even modest workloads reach **₹5k–₹30k easily**:

* 10 actions × 10k runs/month → ₹8,000
* 15 actions × 25k runs/month → ₹30,000
* Premium connectors → cost doubles or triples

---

# ⭐ Final Summary Table

| Component      | Meaning                                 | Cost               |
| -------------- | --------------------------------------- | ------------------ |
| **Triggers**   | When workflow starts                    | ₹0.08–₹0.20        |
| **Actions**    | Each step                               | ₹0.08–₹3 (premium) |
| **Loops**      | Each iteration = action count increases | Varies             |
| **Connectors** | SQL, Service Bus, SAP                   | ₹0.50–₹12          |


---

### **💠 API Management**

| Tier        | Cost / month                 |
| ----------- | ---------------------------- |
| Consumption | Usage based (~₹0.3 per call) |
| Developer   | ₹6,000–₹7,000                |
| Basic       | ₹20,000–₹25,000              |
| Standard    | ₹80,000–₹1,20,000            |
| Premium     | ₹2.5–4 lakhs                 |

---

# ✔ **Billing Granularity Costs**

### **Per-second**

VMs, AKS, Functions → matching to usage → lower cost.

### **Per-hour**

SQL DB, App Service, Network gateways → fixed pricing → billed even if idle.



---

# ⭐ **Azure Billing Granularity Explained**

Azure services charge you based on **how finely Azure measures your usage**:

---

# ⏱️ **1. Per-Second Billing**

Used for **compute-based, event-driven or container-based** workloads.

### ✔ Services billed per second:

* **Virtual Machines (VMs)**
* **AKS (Node Pool VMs)**
* **Azure Functions**
* **Container Instances**
* **VMSS**

### ✔ What It Means

You **only pay for the exact time the resource runs** — every second counts.

Example:
A VM runs for **10 minutes**.

```
Billed time = 10 mins × 60 = 600 seconds
```

If price = ₹5 per hour:

```
Actual cost = (600 sec / 3600 sec) × 5 = ₹0.83
```

### ✔ Why It’s Cheaper

Because **stopping resources actually stops billing immediately**.

Best for:

* Dev/Test
* Auto-shutdown VMs
* Autoscaling AKS nodes
* Short batch jobs
* Functions triggered occasionally

---

# ⏳ **2. Per-Hour Billing**

Used for **database, platform, or network services** where Azure allocates a dedicated capacity that cannot change every second.

### ✔ Services billed per hour:

* **Azure SQL Database**
* **App Service Plans**
* **VPN Gateways / ExpressRoute**
* **Redis Cache**
* **Cosmos DB (provisioned throughput)**
* **App Service Environment**
* **Azure Bastion**
* **Key Vault (HSM mode)**

### ✔ What It Means

You are billed **for the full hour**, **even if the workload is idle**.

Example:
Azure SQL DB (S0 tier) ~ ₹13 per hour.

If it runs 5 minutes:

```
Billed = Full hour = ₹13
```

### ✔ Why It Costs More

These services reserve dedicated capacity:

* CPU/memory cluster for SQL
* App Service hosting VMs
* Dedicated gateway appliances
* Cache nodes

Azure does **not scale these per second**, so idle time = wasted cost.

---

# 🔥 **Per-Second vs Per-Hour (FinOps View)**

| Billing Type   | Benefits                  | Risks                    | Examples                      |
| -------------- | ------------------------- | ------------------------ | ----------------------------- |
| **Per-second** | Pay only for actual usage | Must automate start/stop | VMs, AKS, Functions           |
| **Per-hour**   | Predictable pricing       | Idle = full charge       | SQL DB, App Service, Gateways |

---

# 🎯 FinOps Optimization Strategy

### For **Per-Second** services

✔ Use auto-shutdown
✔ Use autoscaling
✔ Stop dev VMs on weekends
✔ Use spot VMs for batch workloads

### For **Per-Hour** services

✔ Downscale DB tiers
✔ Move SQL to **serverless** (auto-pause)
✔ Move App Service to **lower SKU**
✔ De-allocate unused gateways
✔ Use **elastic pools** for SQL



---

## 🟦 2.3 Cost Drivers

The largest cost consumers in Azure:

1. Virtual Machines & Scale Sets
2. Managed Disks
3. Database Services (SQL, Cosmos DB)
4. Networking (data egress)
5. Storage
6. Kubernetes node pools

---

## 🟦 2.4 Azure Cost Management Tools

Azure provides built-in tools for cost visibility and governance:

* **Cost Analysis** – visual dashboards
* **Cost Alerts** – based on thresholds
* **Budgets** – monthly/annual budget controls
* **Advisor Recommendations** – rightsizing, reservations
* **Usage Data Export** – push billing files every day
* **Pricing Calculator** – estimate future resources
* **TCO Calculator** – migration modeling

---

## 🟦 2.5 Cost Data File (EA / MCA)

Azure produces daily/monthly usage files containing:

* Resource ID
* Meter Category
* Unit cost
* Quantity
* Effective price
* Tags
* Subscription & Billing Account

This data feeds:

* Cloudability
* Power BI reporting
* Internal cost showback/chargeback models

---

# 💰 **3. Cloud Cost Optimization Fundamentals**

Before learning FinOps, you must understand the sources of waste:

### 🔥 **Common Cost Wastes in Azure**

* Idle VMs
* Over-sized compute
* Underutilized databases
* Orphaned disks & NICs
* Misconfigured scaling
* Unused public IPs
* Always-on dev/test environments
* High egress traffic
* Premium storage used unnecessarily

---

# 🏛️ **4. Introduction to FinOps**

FinOps = *Cloud Financial Operations*
A discipline and culture that combines **financial accountability + engineering ownership** to manage cloud costs.

FinOps is not only cost cutting. It is:

### ✔ Cost visibility

### ✔ Cost optimization

### ✔ Operational excellence

### ✔ Value optimization

### ✔ Strong collaboration between teams

---

# 🌀 **5. The FinOps Lifecycle (Core Framework)**

The FinOps Foundation defines 3 phases:

---

## 🟦 **Phase 1: Inform**

Goal: *“Show where money is going.”*

Activities:

* **Tagging strategy**  -   A structured approach for labeling cloud resources using tags (e.g., CostCenter=Finance, Env=Prod).
* **Cost allocation**   -   Process of assigning cloud spend to the right teams, applications, environments, or business units.
* **Shared cost modeling**  -   Method of distributing costs for shared infrastructure (e.g., VPN gateways, firewalls, hub networks). Approaches: proportional allocation, fixed percentage, usage-based.
* **Budgeting** -   Defining spending limits per team, application, or environment.
* **Unit economics**    -   Measuring cost efficiency in meaningful business units. Ex: cost per user, cost per API call, cost per VM hour, cost per environment
* **Forecasting**   -   Predicting future cloud spend based on historical trends, usage patterns, and upcoming changes.
* **Usage data export** -   Exporting raw consumption and cost data from Azure (or other clouds) into tools like:Azure Cost Management exports, Storage accounts, Data Lake, Storage accounts, Data Lake
* **Cloudability integration**  -   Connecting Azure billing data to Apptio Cloudability to enrich cost visibility.

Outputs:

* Dashboards
* Visibility reports
* Cost allocation model

---

## 🟦 **Phase 2: Optimize**

Goal: *“Get the best value for money.”*

Activities:

* **Rightsizing workloads** -   Adjusting compute, storage, and database resources to match actual usage.
* **Scaling policies**  -   Implementing autoscaling rules that grow or shrink capacity based on demand.
* **Optimize data transfer**    -   Reducing network egress fees by optimizing communication patterns
* **Optimize storage**  -   Choosing correct storage tiers and eliminating unused volumes.
* **Reservation purchases (1Y/3Y)** -   Commitment-based discounts for predictable workloads.
* **Savings Plans** -   Flexible commitment to compute spend instead of specific VM types.
* **Spot workloads**    -   Using surplus Azure capacity at deep discounts (up to 90%).
* **Deleting unused resources** -   Systematically identifying and removing unused or idle cloud assets.
* **Architectural improvements**    -   Re-designing systems to be inherently cost-efficient.

Outputs:

* Savings realized
* Optimization backlog
* Monthly savings report

---

## 🟦 **Phase 3: Operate**

Goal: *“Create processes and governance to manage cost at scale.”*

Activities:

* **Governance via policy** -   Establishing rules to enforce compliant and cost-efficient cloud usage.
* **Continuous cost monitoring**    -   Daily or weekly monitoring of usage, anomalies, and budget trends.
* **Monthly FinOps reviews**    -   Regular reviews with engineering, product, and finance teams.
* **KPI reporting** -   Tracking metrics that measure financial performance of cloud usage.
* **Budget enforcement**    -   Ensuring no one exceeds approved spending limits.
* **Team accountability**   -   Assigning spend ownership to each product/service/team.
* **Process automation**    -   Automating repetitive FinOps workflows so cost control scales.

Outputs:

* FinOps dashboard
* Root cause analysis
* Consistent KPIs

---

# 🧰 **6. FinOps Roles & Stakeholders**

FinOps is cross-functional:

### 👨‍💻 Engineering Teams

* Optimize architecture
* Right-size resources
* Automate environments

### 💼 Finance

* Budget planning
* Forecasting
* Chargeback

### 🔐 Cloud Governance

* Enforce policies
* Tag compliance

### 👥 Executives / Product Owners

* Cost accountability
* Funding decisions

### 🛠 FinOps Engineer (YOU)

* Build dashboards
* Integrate Cloudability
* Analyze cost data
* Recommend optimization
* Maintain governance

---

# 🧮 **7. Key FinOps Metrics & KPIs**

* Cost per workload
* Cost per environment
* Cost per customer
* Cost per transaction
* Utilization rate
* RI coverage & utilization
* Percentage of wasted spend
* Cost vs forecast

These feed decision-making.

---

# 🧩 **8. Cloudability Role in FinOps**

Apptio Cloudability integrates with Azure to provide:

* Cost normalization
* Detailed analytics
* Business mappings (cost allocation rules)
* Chargeback/showback
* RI recommendations
* Unit cost analysis
* Multi-cloud governance
* Cost anomaly detection

Azure Cost Management is limited; Cloudability extends insights using **FinOps-aligned analytics**.

---

# 📚 **9. Summary — What You Should Now Understand**

By the end of this module, you should be able to:

### ✔ Explain cloud service & deployment models

### ✔ Understand Azure billing structure

### ✔ Identify major cloud cost drivers

### ✔ Read Azure cost & usage data

### ✔ Know the FinOps lifecycle (Inform–Optimize–Operate)

### ✔ Understand the role of Cloudability in FinOps

### ✔ Explain why tagging and cost governance matters

---

